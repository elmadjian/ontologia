owllib
======

OWL API for python, built using rdflib
